console.log(fxhash)
console.log(fxhashValues)
console.log(fxhashValues2)